#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Check','Install','Uninstall','RemoveOldYasuke')][string]$Action,
    [Parameter(Mandatory=$true)][string]$GameDirectory
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$packageRoot=(Resolve-Path -LiteralPath $PSScriptRoot).Path.TrimEnd('\')
$gameRoot=(Resolve-Path -LiteralPath $GameDirectory).Path.TrimEnd('\')
if ($packageRoot -eq $gameRoot -or $packageRoot.StartsWith($gameRoot+'\',[StringComparison]::OrdinalIgnoreCase) -or $gameRoot.StartsWith($packageRoot+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Extract the package outside the game folder.' }
function Assert-Directory([string]$Path) {
    $item=Get-Item -LiteralPath $Path -Force
    if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Expected a regular directory.' }
}
function Child([string]$Root,[string]$Name) {
    if ([IO.Path]::GetFileName($Name) -ne $Name -or $Name -in @('.','..')) { throw 'Invalid filename.' }
    $path=[IO.Path]::GetFullPath((Join-Path $Root $Name))
    if ([IO.Path]::GetDirectoryName($path) -ne $Root) { throw 'Path escaped its directory.' }
    return $path
}
function SpecPath([string]$Root,$Spec) {
    if ($Spec.group -eq 'base') { return Child $Root $Spec.name }
    if ($Spec.group -ne 'dlc_20') { throw 'Invalid manifest group.' }
    $folder=Child $Root 'dlc_20'
    if (Test-Path -LiteralPath $folder) { Assert-Directory $folder }
    return Child $folder $Spec.name
}
function Regular([string]$Path) {
    $item=Get-Item -LiteralPath $Path -Force
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Expected a regular file.' }
    return $item
}
function Matches([string]$Path,$Spec) {
    $item=Regular $Path
    if ($item.Length -ne [long]$Spec.bytes) { return $false }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -eq $Spec.sha256
}
function Assert-Match([string]$Path,$Spec) {
    if (-not (Matches $Path $Spec)) { throw ('Hash or size mismatch: '+[IO.Path]::GetFileName($Path)+'. Existing files are preserved.') }
}
function Assert-GameClosed {
    if (@(Get-Process -Name ACShadows,ACShadows_Plus -ErrorAction SilentlyContinue).Count) { throw 'Close Assassin''s Creed Shadows first.' }
}
Assert-Directory $gameRoot
Assert-Directory $packageRoot
Regular (Child $gameRoot 'ACShadows.exe') | Out-Null
$manifest=Get-Content -LiteralPath (Child $packageRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($manifest.schema -ne 4 -or $manifest.mod_id -ne 'acshadows-japanese-samurai' -or $manifest.version -ne '1.0.3-sakura-compat') { throw 'Unsupported manifest.' }
$payload=@($manifest.files)
$baseline=@($manifest.baseline)
$oldFiles=@($manifest.previous_base_files)
$variants=@($manifest.sakura_variants)
$prerequisite=$manifest.sakura_prerequisite
function Assert-Names($Specs,$Names) {
    if (@($Specs).Count -ne @($Names).Count -or @(Compare-Object @($Specs.name | Sort-Object) @($Names | Sort-Object)).Count) { throw 'Invalid manifest file list.' }
}
Assert-Names $payload @('DataPC_boot_patch_07.forge','DataPC_boot_20_dlc_patch_02.forge')
Assert-Names $baseline @('DataPC_boot.forge','DataPC_boot_patch_01.forge','DataPC_boot_patch_02.forge','DataPC_boot_20_dlc.forge','DataPC_boot_20_dlc_patch_01.forge')
Assert-Names $oldFiles @(3..9 | ForEach-Object { 'DataPC_boot_patch_{0:00}.forge' -f $_ })
if ($prerequisite.name -ne 'DataPC_boot_patch_03.forge' -or $variants.Count -ne 10 -or @($variants | Where-Object { $_.name -ne 'DataPC_boot_patch_04.forge' }).Count -or @($variants.sha256 | Select-Object -Unique).Count -ne 10) { throw 'Invalid Sakura variant list.' }
foreach ($spec in @($payload)+@($baseline)+@($oldFiles)+@($variants)+@($prerequisite)) {
    if ($spec.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or [long]$spec.bytes -le 0) { throw 'Invalid manifest hash or size.' }
    $expectedGroup=if ($spec.name.StartsWith('DataPC_boot_20_dlc')) {'dlc_20'} else {'base'}
    if ($spec.group -ne $expectedGroup) { throw 'Invalid manifest group.' }
    SpecPath $gameRoot $spec | Out-Null
}
$payloadRoot=Child $packageRoot 'Files'
Assert-Directory $payloadRoot
foreach ($spec in $payload) { Assert-Match (SpecPath $payloadRoot $spec) $spec }
$sakuraPath=SpecPath $gameRoot $prerequisite
$variantPath=Child $gameRoot 'DataPC_boot_patch_04.forge'
$variant=$null
if (Test-Path -LiteralPath $variantPath) {
    foreach ($candidate in $variants) { if (Matches $variantPath $candidate) { $variant=$candidate; break } }
}
$baseFile=@($payload | Where-Object group -eq 'base')[0]
$knownOld=@()
foreach ($item in @(Get-ChildItem -LiteralPath $gameRoot -Force | Where-Object { $_.Name -match '^DataPC_boot_patch_(\d+)\.forge$' -and [int]$Matches[1] -ge 3 })) {
    if ($item.Name -eq $baseFile.name -and (Matches $item.FullName $baseFile)) {
        if ($Action -eq 'RemoveOldYasuke') { throw 'Remove this compatibility edition with Uninstall before cleaning up older files.' }
        continue
    }
    if ($item.Name -eq $prerequisite.name -and (Matches $item.FullName $prerequisite)) { continue }
    if ($item.Name -eq 'DataPC_boot_patch_04.forge' -and $null -ne $variant) { continue }
    $old=@($oldFiles | Where-Object name -eq $item.Name)
    if ($old.Count -eq 1 -and (Matches $item.FullName $old[0])) { $knownOld+=$old[0]; continue }
    throw ('Unrecognised or later boot patch: '+$item.Name+'. No file has been changed.')
}
if ($Action -ne 'RemoveOldYasuke' -and $knownOld.Count) { throw 'Old Yasuke files remain. Run RemoveOldYasuke first; it preserves recognised Sakura files.' }
if ($Action -in @('Check','Install')) {
    if (-not (Test-Path -LiteralPath $sakuraPath)) { throw 'Install Sakura prerequisite patch 03 first.' }
    Assert-Match $sakuraPath $prerequisite
    if ($null -eq $variant) { throw 'Install exactly one supported Sakura variant as patch 04 first.' }
}
$dlcRoot=Child $gameRoot 'dlc_20'
$hasDlc=$false
if (Test-Path -LiteralPath $dlcRoot) {
    Assert-Directory $dlcRoot
    $hasDlc=@(Get-ChildItem -LiteralPath $dlcRoot -Force | Where-Object { $_.Name -eq 'DataPC_boot_20_dlc.forge' -or $_.Name -match '^DataPC_boot_20_dlc_patch_\d+\.forge$' }).Count -gt 0
}
$activePayload=@($payload | Where-Object { $_.group -eq 'base' -or $hasDlc })
$installed=@()
if ($Action -ne 'RemoveOldYasuke') {
    if ($hasDlc -and @(Get-ChildItem -LiteralPath $dlcRoot -Force | Where-Object { $_.Name -match '^DataPC_boot_20_dlc_patch_(\d+)\.forge$' -and [int]$Matches[1] -ge 2 -and $_.Name -ne 'DataPC_boot_20_dlc_patch_02.forge' }).Count) { throw 'Other/later DLC boot patches are present.' }
    foreach ($spec in $activePayload) {
        $path=SpecPath $gameRoot $spec
        if (Test-Path -LiteralPath $path) { Assert-Match $path $spec; $installed+=$spec }
    }
}
if ($Action -in @('Check','Install')) {
    Write-Host 'Checking supported original archives (about 43 GB, or 47 GB with the expansion). This may take a few minutes.'
    foreach ($spec in @($baseline | Where-Object { $_.group -eq 'base' -or $hasDlc })) { Assert-Match (SpecPath $gameRoot $spec) $spec }
}
if ($Action -eq 'Check') {
    [pscustomobject]@{Result='PASS';InstalledFiles=$installed.Count;RequiredFiles=$activePayload.Count;SakuraVariant=$variant.variant;Runtime='NOT_TESTED'}
    return
}
Assert-GameClosed
$removedRoot=Child $packageRoot 'Removed'
if (Test-Path -LiteralPath $removedRoot) { Assert-Directory $removedRoot }
$recovery=Child $removedRoot ((Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
function Preserve($Spec) {
    $source=SpecPath $gameRoot $Spec
    Assert-Match $source $Spec
    if (Test-Path -LiteralPath $removedRoot) { Assert-Directory $removedRoot }
    $target=SpecPath $recovery $Spec
    if (-not $target.StartsWith($packageRoot+'\Removed\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Recovery escaped package.' }
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
    Assert-Directory ([IO.Path]::GetDirectoryName($target))
    if (Test-Path -LiteralPath $target) { throw 'Recovery destination already exists.' }
    [IO.File]::Move($source,$target)
    Assert-Match $target $Spec
}
if ($Action -in @('Uninstall','RemoveOldYasuke')) {
    $remove=@(if ($Action -eq 'RemoveOldYasuke') { $knownOld } else { $installed })
    $moved=@()
    try {
        foreach ($spec in @($remove | Sort-Object group,name -Descending)) {
            Assert-GameClosed
            Preserve $spec
            $moved+=$spec
        }
    } catch {
        $failure=$_
        foreach ($spec in @($moved | Sort-Object group,name)) {
            try {
                Assert-GameClosed
                $saved=SpecPath $recovery $spec
                $destination=SpecPath $gameRoot $spec
                Assert-Match $saved $spec
                if (Test-Path -LiteralPath $destination) { throw 'Restore destination occupied.' }
                [IO.File]::Move($saved,$destination)
            } catch { Write-Warning ('Restore needs attention: '+$spec.name+'. Recovery: '+$recovery) }
        }
        throw $failure
    }
    [pscustomobject]@{Result='PASS';Action=$Action;RemovedFiles=$moved.Count;Recovery=$(if($moved.Count){$recovery}else{''});SakuraFilesChanged=0;OriginalGameFilesChanged=0}
    return
}
$created=@(); $temporary=$null
function Assert-NoNewPatches {
    $unexpected=@(Get-ChildItem -LiteralPath $gameRoot -Force | Where-Object { $_.Name -match '^DataPC_boot_patch_(\d+)\.forge$' -and [int]$Matches[1] -ge 3 -and $_.Name -notin @('DataPC_boot_patch_03.forge','DataPC_boot_patch_04.forge','DataPC_boot_patch_07.forge') })
    if ($unexpected.Count) { throw 'Boot patch layout changed during installation.' }
    if ($hasDlc -and @(Get-ChildItem -LiteralPath $dlcRoot -Force | Where-Object { $_.Name -match '^DataPC_boot_20_dlc_patch_(\d+)\.forge$' -and [int]$Matches[1] -ge 2 -and $_.Name -ne 'DataPC_boot_20_dlc_patch_02.forge' }).Count) { throw 'DLC patch layout changed during installation.' }
}
try {
    # Recheck both third-party parents after the potentially lengthy baseline hashing.
    Assert-Match $sakuraPath $prerequisite
    Assert-Match $variantPath $variant
    foreach ($spec in $activePayload) {
        $target=SpecPath $gameRoot $spec
        if (Test-Path -LiteralPath $target) { Assert-Match $target $spec; continue }
        Assert-GameClosed
        $temporary=Child ([IO.Path]::GetDirectoryName($target)) ('.KuroganeSakura-'+[Guid]::NewGuid().ToString('N')+'.tmp')
        $source=[IO.File]::OpenRead((SpecPath $payloadRoot $spec))
        try {
            $destination=[IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
            try { $source.CopyTo($destination) } finally { $destination.Dispose() }
        } finally { $source.Dispose() }
        Assert-Match $temporary $spec
        Assert-GameClosed
        Assert-Match $sakuraPath $prerequisite
        Assert-Match $variantPath $variant
        Assert-NoNewPatches
        [IO.File]::Move($temporary,$target)
        $temporary=$null; $created+=$spec
        Assert-Match $target $spec
    }
} catch {
    $failure=$_
    foreach ($spec in @($created | Sort-Object group,name -Descending)) {
        try { Preserve $spec } catch { Write-Warning ('Rollback needs attention: '+$spec.name) }
    }
    if ($temporary -and (Test-Path -LiteralPath $temporary)) {
        if ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($temporary)) -notin @($gameRoot,$dlcRoot)) { throw 'Temporary path escaped game folders.' }
        if (Test-Path -LiteralPath $removedRoot) { Assert-Directory $removedRoot }
        [IO.Directory]::CreateDirectory($recovery) | Out-Null
        [IO.File]::Move($temporary,(Child $recovery ([IO.Path]::GetFileName($temporary))))
    }
    throw $failure
}
[pscustomobject]@{Result='PASS';Action='Install';NewFiles=$created.Count;AlreadyPresent=$installed.Count;ExpansionIncluded=$hasDlc;SakuraFilesChanged=0;OriginalGameFilesChanged=0;Runtime='NOT_TESTED'}
