﻿#requires -Version 5.1
<#!
Standalone manager for the exact Kurogane Yasuke release.
Check is read-only. Install never overwrites. Uninstall preserves exact owned files.
!#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Check','Install','Uninstall')][string]$Action,
    [Parameter(Mandatory=$true)][string]$GameDirectory
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$packageRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path.TrimEnd('\')
$gameRoot = (Resolve-Path -LiteralPath $GameDirectory).Path.TrimEnd('\')
if ($gameRoot -eq $packageRoot -or $packageRoot.StartsWith($gameRoot+'\',[StringComparison]::OrdinalIgnoreCase) -or $gameRoot.StartsWith($packageRoot+'\',[StringComparison]::OrdinalIgnoreCase)) {
    throw 'Extract the release outside the game folder before using this manager.'
}
function Get-ChildPath([string]$Parent,[string]$Name) {
    if ([IO.Path]::GetFileName($Name) -ne $Name -or $Name -in @('.','..')) { throw 'Invalid manifest filename.' }
    $p = [IO.Path]::GetFullPath((Join-Path $Parent $Name))
    if ([IO.Path]::GetDirectoryName($p) -ne $Parent) { throw 'Path escaped its intended directory.' }
    return $p
}
function Assert-RegularFile([string]$Path) {
    $f = Get-Item -LiteralPath $Path -Force
    if ($f.PSIsContainer -or ($f.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Expected a regular file: $Path" }
    return $f
}
function Assert-Match([string]$Path,$Spec) {
    $f = Assert-RegularFile $Path
    if ($f.Length -ne [long]$Spec.bytes) { throw "File size differs from the supported release: $($f.Name)" }
    if ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -ne $Spec.sha256) { throw "SHA256 mismatch: $($f.Name). No existing file will be overwritten." }
}
function Assert-GameClosed {
    if (@(Get-Process -Name ACShadows,ACShadows_Plus -ErrorAction SilentlyContinue).Count) { throw 'Close Assassin''s Creed Shadows before installing or removing the mod.' }
}
Assert-RegularFile (Get-ChildPath $gameRoot 'ACShadows.exe') | Out-Null
$manifest = Get-Content -LiteralPath (Join-Path $packageRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($manifest.schema -ne 1 -or $manifest.mod_id -ne 'acshadows-japanese-samurai' -or $manifest.version -ne '1.0.2') { throw 'Unsupported release manifest.' }
$expectedNames = @(3..8 | ForEach-Object { 'DataPC_boot_patch_{0:00}.forge' -f $_ })
$payload = @($manifest.files | Sort-Object name)
if ($payload.Count -ne 6 -or @(Compare-Object $expectedNames @($payload.name)).Count) { throw 'The complete six-file payload is required.' }
if (@($manifest.baseline).Count -ne 3 -or @(Compare-Object @('DataPC_boot.forge','DataPC_boot_patch_01.forge','DataPC_boot_patch_02.forge') @($manifest.baseline.name)).Count) { throw 'Invalid baseline manifest.' }
foreach ($spec in @($payload)+@($manifest.baseline)) {
    if ($spec.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or [long]$spec.bytes -le 0) { throw 'Invalid manifest hash or size.' }
}
$payloadRoot = Join-Path $packageRoot 'Files'
foreach ($spec in $payload) { Assert-Match (Get-ChildPath $payloadRoot $spec.name) $spec }
$extraPatches = @(Get-ChildItem -LiteralPath $gameRoot -File | Where-Object {
    $_.Name -match '^DataPC_boot_patch_(\d+)\.forge$' -and [int]$Matches[1] -ge 3 -and $_.Name -notin $expectedNames
})
if ($extraPatches.Count) { throw ('Other/later boot patches are present: '+($extraPatches.Name -join ', ')+'. Resolve their dependency chain before using this release; do not rename patches.') }
$installed = @()
foreach ($spec in $payload) {
    $target = Get-ChildPath $gameRoot $spec.name
    if (Test-Path -LiteralPath $target) { Assert-Match $target $spec; $installed += $spec }
}
if ($Action -ne 'Uninstall') {
    Write-Host 'Checking the supported game archives (about 43 GB read; no copying). This can take a few minutes.'
    foreach ($spec in $manifest.baseline) {
        Write-Host ('Checking '+$spec.name)
        Assert-Match (Get-ChildPath $gameRoot $spec.name) $spec
    }
}
if ($Action -eq 'Check') {
    [pscustomobject]@{Result='PASS';Action='Check';Version=$manifest.version;InstalledFiles=$installed.Count;RequiredFiles=6;GameDirectory=$gameRoot;Meaning='Payload, baseline hashes and patch slots match. In-game compatibility on this computer is not tested.'}
    return
}
Assert-GameClosed
$stamp = (Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)
$recovery = [IO.Path]::GetFullPath((Join-Path $packageRoot ('Removed\'+$stamp)))
if (-not $recovery.StartsWith($packageRoot+'\Removed\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid recovery path.' }
function Preserve-Owned([string]$Path,$Spec) {
    if ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Path)) -ne $gameRoot) { throw 'Removal target is outside the game root.' }
    Assert-Match $Path $Spec
    [IO.Directory]::CreateDirectory($recovery) | Out-Null
    $destination = Get-ChildPath $recovery $Spec.name
    if (Test-Path -LiteralPath $destination) { throw 'Recovery target already exists.' }
    Move-Item -LiteralPath $Path -Destination $destination
    Assert-Match $destination $Spec
    if (Test-Path -LiteralPath $Path) { throw 'Removal did not complete.' }
}
if ($Action -eq 'Uninstall') {
    # All installed files were checked before the first move. Preserve later ancestors first.
    foreach ($spec in @($installed | Sort-Object name -Descending)) {
        Assert-GameClosed
        Preserve-Owned (Get-ChildPath $gameRoot $spec.name) $spec
    }
    [pscustomobject]@{Result='PASS';Action='Uninstall';RemovedFiles=$installed.Count;PreservedAt=$(if ($installed.Count) {$recovery} else {''});OriginalGameFilesChanged=0}
    return
}
$created = @()
$temporaryPath = $null
try {
    foreach ($spec in $payload) {
        $target = Get-ChildPath $gameRoot $spec.name
        if (Test-Path -LiteralPath $target) { Assert-Match $target $spec; continue }
        Assert-GameClosed
        $temporaryPath = Get-ChildPath $gameRoot ('.JapaneseSamurai-'+[Guid]::NewGuid().ToString('N')+'.tmp')
        $sourceStream = [IO.File]::OpenRead((Get-ChildPath $payloadRoot $spec.name))
        try {
            $destStream = [IO.File]::Open($temporaryPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
            try { $sourceStream.CopyTo($destStream) } finally { $destStream.Dispose() }
        } finally { $sourceStream.Dispose() }
        Assert-Match $temporaryPath $spec
        Assert-GameClosed
        [IO.File]::Move($temporaryPath,$target) # Two-argument Move refuses an existing destination.
        $temporaryPath = $null
        $created += $spec
        Assert-Match $target $spec
    }
} catch {
    $failure = $_
    # Only files created by this invocation are eligible for rollback; no recursive deletion.
    foreach ($spec in @($created | Sort-Object name -Descending)) {
        try { Preserve-Owned (Get-ChildPath $gameRoot $spec.name) $spec }
        catch { Write-Warning ('Rollback needs attention for '+$spec.name+': '+$_.Exception.Message) }
    }
    if ($temporaryPath -and (Test-Path -LiteralPath $temporaryPath)) {
        if ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($temporaryPath)) -ne $gameRoot) { throw 'Temporary path escaped game root.' }
        [IO.Directory]::CreateDirectory($recovery) | Out-Null
        Move-Item -LiteralPath $temporaryPath -Destination (Get-ChildPath $recovery ([IO.Path]::GetFileName($temporaryPath)))
    }
    throw $failure
}
[pscustomobject]@{Result='PASS';Action='Install';Version=$manifest.version;NewFiles=$created.Count;PreviouslyPresent=$installed.Count;OriginalGameFilesChanged=0;Runtime='NOT RUN on this computer - launch and inspect Yasuke'}
